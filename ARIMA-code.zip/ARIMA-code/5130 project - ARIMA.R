#### ARIMA Model####
#### data processing ####
Daily_CN = read.table("/Users/zisyun/Desktop/5130\ HW/project/data/Daily\ CN.txt", header = T)
summary(Daily_CN)
daily_CN = as.data.frame(Daily_CN)

daily_ZZ = daily_CN[c(1:2190),2] ## use 2008-2016 data as the training set
test_ZZ = daily_CN[c(2191:2985),2] ## use 2017-2020 data as the training set
ZZ = daily_CN[,2]
log_daily_ZZ = diff(log(ZZ))*100
summary(log_daily_ZZ)

daily_HS = daily_CN[c(1:2190), 3] ## use 2008-2016 data as the training set
test_HS = daily_CN[c(2191:2985),3] ## use 2017-2020 data as the training set
HS = daily_CN[,3]
log_daily_HS = diff(log(HS))*100
summary(log_daily_HS)

Daily_HK = read.table("/Users/zisyun/Desktop/5130\ HW/project/data/Daily\ HK.txt", header = T)
summary(Daily_HK)

daily_HK = as.data.frame(Daily_HK)
daily_HSI = daily_HK[c(1:2212), 2] ## use 2008-2016 data as the training set
test_HSI = daily_HK[c(2213:3017),2] ## use 2017-2020 data as the training set
HSI = daily_HK[,2]
log_daily_HSI = diff(log(HSI))*100
summary(daily_HSI)

Daily_US = read.table("/Users/zisyun/Desktop/5130\ HW/project/data/Daily\ US.txt", header = T)
summary(Daily_US)

daily_US = as.data.frame(Daily_US)
daily_SP = daily_US[c(1:2267), 2] ## use 2008-2016 data as the training set
test_SP = daily_US[c(2268:3089),2] ## use 2017-2020 data as the training set
SP = daily_US[,2]
log_daily_SP = diff(log(SP))*100
summary(log_daily_SP)

daily_IXIC = daily_US[c(1:2267), 3] ## use 2008-2016 data as the training set
test_IXIC = daily_US[c(2268:3089),3] ## use 2017-2020 data as the training set
IXIC = daily_US[,3]
log_daily_IXIC = diff(log(IXIC))*100
summary(log_daily_IXIC)

## convert the data into the percentage log return 
log_ZZ = diff(log(daily_ZZ))*100
log_ZZ_test = diff(log(test_ZZ))*100
log_HS =  diff(log(daily_HS))*100
log_HS_test = diff(log(test_HS))*100
log_HSI =  diff(log(daily_HSI))*100
log_HSI_test = diff(log(test_HSI))*100
log_SP =  diff(log(daily_SP))*100
log_SP_test = diff(log(test_SP))*100
log_IXIC =  diff(log(daily_IXIC))*100
log_IXIC_test = diff(log(test_IXIC))*100

#### Packages ####
library(tseries)
library(fGarch)
library(timeSeries)
library(forecast)
library(caret)       

#### Analysis of ZZ500 log return ####
print(adf.test(log_ZZ)) ##Firstly conduct an ADF test for the ZZ500 close price set

par(mfrow=c(2,1))
acf(log_ZZ)
pacf(log_ZZ)

model_ZZ <- auto.arima(log_ZZ, lambda = "auto") ## We apply auto arima to the dataset 
model_ZZ

Box.test(model_ZZ$residuals,lag=12,type='Ljung')

tsdiag(model_ZZ)

forecast_ZZ = forecast(model_ZZ, h= length(log_ZZ_test)) ## Forcast from ARIMA Model
plot(forecast_ZZ)
par(new = TRUE)
plot(log_daily_ZZ , ylab="log return of ZZ500", type="l" )

#### Analysis of CN HS300 log return ####
print(adf.test(log_HS)) #Firstly conduct an ADF test for the ZZ500 close price set

par(mfrow=c(2,1))
acf(log_HS)
pacf(log_HS)

model_HS <- auto.arima(log_HS, lambda = "auto") ## We apply auto arima to the dataset
model_HS
Box.test(model_HS$residuals,lag=12,type='Ljung')
tsdiag(model_HS)

forecast_HS = forecast(model_HS, h=length(log_HS_test)) ## Forcast from ARIMA Model
plot(forecast_HS)
par(new = TRUE)
plot(log_daily_HS , ylab="log return of HS300", type="l" )

#### Analysis of HSI log return ####
print(adf.test(log_HSI)) #Firstly conduct an ADF test for the HSI close price set

par(mfrow=c(2,1))
acf(log_HSI)
pacf(log_HSI)

model_HSI <- auto.arima(log_HSI, lambda = "auto") ## We apply auto arima to the dataset
model_HSI

Box.test(model_HSI$residuals,lag=12,type='Ljung')

tsdiag(model_HSI)

forecast_HSI = forecast(model_HSI, h=length(log_HSI_test)) ## Forcast from ARIMA Model
plot(forecast_HSI)
par(new = TRUE)
plot(log_daily_HSI , ylab="log return of HSI", type="l" )

#### Analysis of SP500 log return ####
print(adf.test(log_SP))#Firstly conduct an ADF test for the SP500 close price set

par(mfrow=c(2,1))
acf(log_SP)
pacf(log_SP)

model_SP <- auto.arima(log_SP, lambda = "auto") ## We apply auto arima to the dataset 
model_SP

Box.test(model_SP$residuals,lag=12,type='Ljung')

tsdiag(model_SP)

forecast_SP = forecast(model_SP, h=length(log_SP_test)) ## Forcast from ARIMA Model
plot(forecast_SP , ylim = c(-10,10))
par(new = TRUE)
plot(log_daily_SP , ylab="log return of SP500", type="l" , ylim = c(-10,10))




#### Analysis of IXIC log return ####

print(adf.test(log_IXIC)) #Firstly conduct an ADF test for the IXIC close price set

par(mfrow=c(2,1))
acf(log_IXIC)
pacf(log_IXIC)

model_IXIC <- auto.arima(log_IXIC, lambda = "auto") ## We apply auto arima to the dataset 
model_IXIC

Box.test(model_IXIC$residuals,lag=12,type='Ljung')

tsdiag(model_IXIC)

forecast_IXIC = forecast(model_IXIC, h=length(log_IXIC_test)) ## Forcast from ARIMA Model
plot(forecast_IXIC , ylim=c(-10,10))
par(new = TRUE)
plot(log_daily_IXIC , ylab="log return of IXIC", type="l" , ylim=c(-10,10))

###Compute the MSE of models
accuracy(forecast_ZZ, log_ZZ_test) 
accuracy(forecast_HS, log_HS_test) 
accuracy(forecast_HSI, log_HSI_test)
accuracy(forecast_SP, log_SP_test)
accuracy(forecast_IXIC, log_IXIC_test)
