data = read.table("/Users/zhouquan/Desktop/monthly_data.txt")
sp500 = data$SP500
plot(sp500, type ="l")
### convert the data into the percentage log return 
log_sp500 = diff(log(sp500))*100
### we first plot the picture of the log return but dind there are no seasonal change.
plot(log_sp500)
#### check if the series is stationary and have arch effect.
library(FinTS)
ArchTest(log_sp500, lags= 10)
# p-value = 2.317e-05, reject the Null Hypothesis, it exists arch effect.
library(tseries)
library(forecast)
adf.test(log_sp500)
# p = 0.01, reject the Null hypothesis, the series is stationary.
# we consider some forms of GARCH model because we have arch effect.
# check the acf of the log_sp500 series to roughly judge the AR and MA parameter.
acf(log_sp500)
pacf(log_sp500)
# ar term seems not significant, ma term assume 1.
auto.arima(log_sp500) # we ensure the arima(2,0,2) because it has the lowest aic.
# auto.arima has zero mean.
# construct the GARCH-M model cause it describes the features of the stock index.
# the larger the return, the larger the sigma. this model contains sigma in the mean equation.
library(rugarch)
spec1 = ugarchspec(variance.model = list(model="fGARCH",
                                         garchOrder =c(1,1),
                                         submodel="GARCH"),
                   mean.model = list(armaOrder=c(2,2),include.mean=FALSE, archm = TRUE ))
mm = ugarchfit(spec = spec1, data = log_sp500)
mm
stresi = residuals(mm, standardize = T)
Box.test(stresi, 10 ,type = "Ljung") # p = 0.9043
# number of parameters: 8 
p_value = 1-pchisq(4.7975, 2)
p_value ## 0.0908
Box.test(stresi^2, 10 , type ="Ljung") # = 0.9137
p_value = 1 - pchisq(4.6434,2)
p_value ## 0.0981
### we find that if we minus the degree of freedom, the p_value is not so well as we expected.
### maybe we can try if we can reduce the parameter to increase the degree of freedom.
## trying other kinds of model, the parameter is not even significant.
## relatively, this model performs better.
mu.<-fitted(mm)  ### fitted mean value
sig.<-sigma(mm) ### fitted sigma value
plot(stresi) ### seems the residual is randomly distributed.
plot(mm) ## plot the conditional standard error vs returns.
##################
################## we now calculate VaR based on the historical volatility and 
################## the formula: sigma*Zc*principal. we set principal to be 100.
#### setting alpha = 0.05
install.packages("plyr")
library(plyr)
each(max)(sig.)
VaR = 100 - each(max)(sig.)*1.64
VaR ##### 80.93298
### this means that if a client invests 100 USD into the sp500 market, the VaR loss is 
### 19.06702, lefting 80.93298 after one month.

########################################
######################################## use the machine learning to check 
######################################## if the model is good.
train = data[1:138,]
train_SP500 = train$SP500
test = data[139:148,]
test_SP500 = test$SP500
log_train_SP500 = diff(log(train_SP500))*100
log_test_SP500 = diff(log(test_SP500))*100
train_days =length(log_train_SP500)
test_days = length(log_test_SP500)
spec1 = ugarchspec(variance.model = list(model="fGARCH",
                                         garchOrder =c(1,1),
                                         submodel="GARCH"),
                   mean.model = list(armaOrder=c(2,2),include.mean=FALSE, archm = TRUE ))
mm = ugarchfit(spec = spec1, data = log_train_SP500)
mm
fore=ugarchforecast(mm,n.ahead=test_days)
foreyield <- fore@forecast[["seriesFor"]]
foreyield.1 = as.numeric(foreyield)
log_test_SP500.1 = as.numeric(log_test_SP500)
index = seq(1, test_days,1)
a<- data.frame(index,foreyield.1, log_test_SP500.1)
library(ggplot2)
ggplot(a)+geom_line(aes(x = index,y=log_test_SP500.1,group=1),color="chartreuse3")+
  geom_line(aes(x= index,y=foreyield.1,group=1),color="red")
a
#### use MSE to measure the model condition
square_error <- data.frame(matrix(0,nrow(a),1))
names(square_error)<- c("GARCH")
for(i in 1: nrow(a)){
  square_error[i,1] = (a[i,2] - a[i,3])^2
}
MSE <- mean(square_error$GARCH)
####### we also use MAE to measure the model condition
square_error2 <- data.frame(matrix(0,nrow(a),1))
names(square_error2)<- c("GARCH")
for(i in 1: nrow(a)){
  square_error[i,1] = sqrt((a[i,2] - a[i,3])^2)
}
MAE <- mean(square_error$GARCH)
##########################################################
# change the monthly dataset into the daily dataset.
# we use the sp500 daily data to build GARCH-M model.
data = read.table("/Users/zhouquan/Desktop/dailydata.txt")
SP500 =data$SP500 ## we use the SP500 data to build the model.
# plot the picture of SP500 index throughout the period. see if it is stationary.
plot(SP500, type ="l")
### obviously, original SP500 data is non-stationary.
### convert the SP500 data into log return data.
log_SP500 =diff(log(SP500))
## plot the log return of SP500 and see if it is stationary.
plot(log_SP500, type ="l")
library(FinTS)
ArchTest(log_SP500, lags = 10)
## we check the arch effect, p-value is very small, reject the null hypothesis. Identify there are arch effects.
library(tseries)
library(forecast)
adf.test(log_SP500) ## p = 0.01,the series is stationary.
# we consider some forms of GARCH model because we have arch effect.
# check the acf of the log_sp500 series to roughly judge the AR and MA parameter.
acf(log_SP500)
pacf(log_SP500)
### we check the lag1 is significant, we guess AR1 or MA1
### use autoarima function
auto.arima(log_SP500)
### we got ARIMA(0,0,1) with zero mean to be the best model. Because it has the lowest AIC.
# construct the GARCH-M model cause it describes the features of the stock index.
# the larger the return, the larger the sigma. this model contains sigma in the mean equation.
library(rugarch)
spec1 = ugarchspec(variance.model = list(model="fGARCH",
                                         garchOrder =c(1,1),
                                         submodel="GARCH"),
                   mean.model = list(armaOrder=c(0,1),include.mean=FALSE, archm = TRUE ))
mm = ugarchfit(spec = spec1, data = log_SP500)
mm
stresi = residuals(mm, standardize = T)
Box.test(stresi, 10 ,type = "Ljung") # p = 0.4773
# number of parameters: 5 
p_value = 1-pchisq(9.5881, 5)
p_value ## p = 0.0878
Box.test(stresi^2, 10 ,type = "Ljung")
p_value = 1-pchisq(12.554,5)
p_value ## p = 0.02793, cannot regard the noise as the white noise.
plot(stresi) ## we see the residual moves around zero.
plot(mm) ## select 3 and get the conditional standard error.
mu.<- fitted(mm)
sig. <-sigma(mm)
#### we analyze the VaR of the principal and set alpha =0.05.
install.packages("plyr")
library(plyr)
each(max)(sig.) ## 0.07611561
VaR = 100 - each(max)(sig.)*1.64
VaR ## VaR value is 99.87517. 
## this means that if a person invest 100 dollars into SP500 index, then after one day,
## the marginal loss will be 0.12. the principal left 99.87517 after one day.
################### now we use the machine learning to divide the training data and the testing data.
### we use 2007-2016 as the training set(first 2268lines) and 2017-2020 as the testing set.

train = data[1:2268,]
train_SP500 = train$SP500
test = data[2269:3094,]
test_SP500 = test$SP500
log_train_SP500 = diff(log(train_SP500))
log_test_SP500 = diff(log(test_SP500))
train_days =length(log_train_SP500)
test_days = length(log_test_SP500)
spec1 = ugarchspec(variance.model = list(model="fGARCH",
                                         garchOrder =c(1,1),
                                         submodel="GARCH"),
                   mean.model = list(armaOrder=c(0,1),include.mean=FALSE, archm = TRUE ))
mm = ugarchfit(spec = spec1, data = log_train_SP500)
mm
fore=ugarchforecast(mm,n.ahead=test_days)
foreyield <- fore@forecast[["seriesFor"]]
foreyield.1 = as.numeric(foreyield)
log_test_SP500.1 = as.numeric(log_test_SP500)
index = seq(1, test_days,1)
a<- data.frame(index,foreyield.1, log_test_SP500.1)
library(ggplot2)
ggplot(a)+geom_line(aes(x = index,y=log_test_SP500.1,group=1),color="chartreuse3")+
  geom_line(aes(x= index,y=foreyield.1,group=1),color="red")
### using MSE criteria cannot visualize the model condition. We plot the forecast obs and actual value.
##  we use MSE to measure the model predicting condition.
a
square_error <- data.frame(matrix(0,nrow(a),1))
names(square_error)<- c("GARCH")
for(i in 1: nrow(a)){
  square_error[i,1] = (a[i,2] - a[i,3])^2
 }
MSE <- mean(square_error$GARCH)
####### we also use MAE to measure the model condition
square_error2 <- data.frame(matrix(0,nrow(a),1))
names(square_error2)<- c("GARCH")
for(i in 1: nrow(a)){
  square_error[i,1] = sqrt((a[i,2] - a[i,3])^2)
}
MAE <- mean(square_error$GARCH)








